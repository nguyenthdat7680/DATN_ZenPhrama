﻿namespace NhaThuocOnline.WebApp.Controllers
{
    internal class TokenValidationParameters
    {
    }
}